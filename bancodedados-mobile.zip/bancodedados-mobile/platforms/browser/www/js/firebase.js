var firebaseConfig = {
    apiKey: "AIzaSyC9TvwTaSAMAuZiuyiBXqYZr1_pzY6Yr9w",
    authDomain: "app-agendamentos-87cbe.firebaseapp.com",
    projectId: "app-agendamentos-87cbe",
    storageBucket: "app-agendamentos-87cbe.appspot.com",
    messagingSenderId: "537553873017",
    appId: "1:537553873017:web:cc77cb94a5b4e3a8218ca8",
    measurementId: "G-B9BW6Y9Q9E"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();